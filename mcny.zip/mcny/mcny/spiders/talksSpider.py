import scrapy
from scrapy.http import HtmlResponse
from scrapy.selector import HtmlXPathSelector
from urlparse import urljoin
from scrapy import Request
import urllib
from scrapy.selector import HtmlXPathSelector

from collections import Counter


class talksSpider(scrapy.Spider):
    name = "talksSpider"
    allowed_domains = ["mcny.org/"]
    start_urls = ["http://mcny.org/events/talks?page=0", "http://mcny.org/events/talks?page=1"]

    def parse(self, response):
    	organization =[]
    	title_eventsObj =[]
    	descriptionsObj =[]
    	eventWebsitesObj =[]
    	ticketUrl = []
    	street = []
    	state = []
    	zipCode = []
    	startTime = []
    	endTime = []
    	eventPriceLabel = []
    	eventPriceDollar = []
    	eventPriceList = []	
    	imageURL = []
    	contactPhone = []
    	
        for talksPage in response.css('section.events-all'):

        	
        	
        	title_eventsObj = talksPage.xpath('.//div[@class="card-block"]//h2/a/text()').extract()
        	descriptionsObj = talksPage.xpath('.//div[@class="card-block"]//div[@class="hidden-sm-down"]/text()').extract()
        	eventWebsitesObj = talksPage.xpath('.//div[@class="card-block"]//h2/a/@href').extract()
        	

        	
        	i = 0 #counter

        	#find more details about the event from event page
        	for eventBulk in eventWebsitesObj:

        		eventWebsite = "http://mcny.org" + eventWebsitesObj[i]
        		#read the event page
        		dataFrom_EventPage = urllib.urlopen(eventWebsite).read()
        		#open the event page
        		event_page = HtmlXPathSelector(text=dataFrom_EventPage)
        		#getting url ticket
        		ticketUrl.append(event_page.xpath('.//*[@class="buy-tix"]//a/@href').extract()[0])
        		#getting image url
        		imageURL.append(event_page.xpath('.//figure[@class="event-image"]/img/@src').extract()[0])
        		#getting organization
        		organization.append(event_page.xpath('.//div[@class="copyright"]/text()').extract()[0])

        		#read the ticket page for bring more fields details
        		dataFrom_TicketPage = urllib.urlopen(ticketUrl[i]).read()
        		ticket_page = HtmlXPathSelector(text=dataFrom_TicketPage)
        		#getting start and end time
        		startTime.append(ticket_page.xpath('.//*[@class="Programming_Event_StartTime"]/text()').extract()[0])
        		endTime.append(ticket_page.xpath('.//*[@class="Programming_Event_EndTime"]/text()').extract()[0])
        		#getting label and price form list of price
        		eventPriceLabel.append(ticket_page.xpath('.//*[@class="Programming_Event_PriceList"]//label/text()').extract())
        		eventPriceDollar.append(ticket_page.xpath('.//*[@class="Programming_Event_PriceList"]//span/text()').extract())
        		#getting address data
        		adress_data = ticket_page.xpath('.//*[@class="MSFootTextDiv"]/p/a/text()').extract()[0]
        		street_aux,state_aux,zipCode_aux = adress_data.split(",")
        		street.append(street_aux)
        		state.append(state_aux)
        		zipCode.append(zipCode_aux)
        		contactPhone.append(ticket_page.xpath('.//*[@class="MSFootTextDiv"]/p/span/text()').extract()[0])



        		print("@@@@")
        		
        		
        		print("### DEBUG ZONE ###")

        		print("----- NUMBER ----- ITEM _____")
        		print(i)
        		
        		
        	

	        	yield{
	        	'organization': organization[i],
	        	'title':title_eventsObj[i],
	        	'description': descriptionsObj[i],
	        	'eventWebsite':eventWebsitesObj[i],
	        	'eventImage': imageURL[i],
	        	'street':street[i],
	        	'state':state[i],
	        	'zip':zipCode[i],
	        	'ticketURL':ticketUrl[i],
	        	'eventImage':imageURL[i],
	        	'eventPriceLabel':eventPriceLabel[i],
	        	'eventPriceDollar':eventPriceDollar[i]

	        	
	        	}
	        	print("$$$")
	        	
	        	i = i + 1 #increment counter
	        	