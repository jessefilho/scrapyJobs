import scrapy

class EventItems(scrapy.Item):
    organization = scrapy.Field()
    description = scrapy.Field()
    title = scrapy.Field()
    ticketUrl = scrapy.Field()
    eventWebsite = scrapy.Field()
    street = scrapy.Field()
    state = scrapy.Field()
    zipCode = scrapy.Field()
    last_updated = scrapy.Field(serializer=str)


